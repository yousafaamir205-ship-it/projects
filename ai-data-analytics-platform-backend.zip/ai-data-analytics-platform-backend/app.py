from flask import Flask
from api.feature_importance import feature_bp
from api.upload import upload_bp
from api.train import train_bp
from api.tuning import tuning_bp
from api.predict import predict_bp
from api.visualizations import visual_bp
from api.report import report_bp
from api.history import history_bp
from api.dashboard import dashboard_bp
from api.cleaning import cleaning_bp
app = Flask(__name__)
app.register_blueprint(predict_bp, url_prefix="/api")
app.register_blueprint(upload_bp, url_prefix="/api")
app.register_blueprint(train_bp, url_prefix="/api")
app.register_blueprint(feature_bp, url_prefix="/api")
app.register_blueprint(tuning_bp, url_prefix="/api")
app.register_blueprint(visual_bp, url_prefix="/api")
app.register_blueprint(report_bp, url_prefix="/api")
app.register_blueprint(history_bp, url_prefix="/api")
app.register_blueprint(dashboard_bp, url_prefix="/api")
app.register_blueprint(cleaning_bp, url_prefix="/api")
@app.route("/")
def home():
    return {
        "message": "AI Data Analytics Platform Backend Running"
    }


if __name__ == "__main__":
    app.run(debug=True)
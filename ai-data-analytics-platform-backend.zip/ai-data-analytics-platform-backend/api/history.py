from flask import Blueprint
from database.connection import get_connection

history_bp = Blueprint("history", __name__)


@history_bp.route("/history", methods=["GET"])
def history():

    connection = get_connection()

    cursor = connection.cursor()

    cursor.execute("SELECT * FROM training_history ORDER BY id DESC")

    rows = cursor.fetchall()

    connection.close()

    history = []

    for row in rows:

        history.append({
            "id": row["id"],
            "filename": row["filename"],
            "model_name": row["model_name"],
            "accuracy": row["accuracy"],
            "created_at": row["created_at"]
        })

    return {
        "status": "success",
        "history": history
    }
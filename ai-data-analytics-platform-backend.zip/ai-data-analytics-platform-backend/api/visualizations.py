import os
import pandas as pd

from flask import Blueprint, request

from analysis.visualizations import generate_visualizations

visual_bp = Blueprint("visualizations", __name__)


@visual_bp.route("/visualizations", methods=["POST"])
def visualizations():

    data = request.get_json()

    filename = data.get("filename")

    if not filename:

        return {
            "status": "error",
            "message": "filename is required."
        }, 400

    dataset_path = os.path.join("uploads", filename)

    if not os.path.exists(dataset_path):

        return {
            "status": "error",
            "message": "Dataset not found."
        }, 404

    df = pd.read_csv(dataset_path)

    images = generate_visualizations(df)

    return {
        "status": "success",
        "generated_images": images
    }
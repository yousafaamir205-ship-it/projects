from flask import Blueprint

from analysis.dashboard import dataset_dashboard

dashboard_bp = Blueprint("dashboard", __name__)


@dashboard_bp.route("/dashboard/<filename>", methods=["GET"])
def dashboard(filename):

    result = dataset_dashboard(filename)

    return result
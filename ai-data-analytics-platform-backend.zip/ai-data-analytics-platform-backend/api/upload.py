from analysis.visualization import generate_visualizations
from analysis.eda import analyze_dataset
import os
import pandas as pd
from flask import Blueprint, request, current_app
from utils.file_handler import allowed_file
upload_bp = Blueprint("upload", __name__)
@upload_bp.route("/api/upload", methods=["POST"])
def upload_file():
    if "file" not in request.files:
        return {
            "status": "error",
            "message": "No file uploaded."
        }, 400
    uploaded_file = request.files["file"]
    if uploaded_file.filename == "":
        return {
            "status": "error",
            "message": "No file selected."
        }, 400
    if not allowed_file(uploaded_file.filename):
        return {
            "status": "error",
            "message": "Only CSV and Excel files are allowed."
        }, 400
    save_path = os.path.join(
        current_app.config["UPLOAD_FOLDER"],
        uploaded_file.filename
    )

    uploaded_file.save(save_path)
    if uploaded_file.filename.endswith(".csv"):
        df = pd.read_csv(save_path)

    else:
        df = pd.read_excel(save_path)
    analysis_result = analyze_dataset(df)
    plots_folder = os.path.join("static", "plots")

    plot_images = generate_visualizations(
        df,
        plots_folder
    )

    return {
    "status": "success",
    "filename": uploaded_file.filename,
    "analysis": analysis_result,
    "plots": plot_images
}
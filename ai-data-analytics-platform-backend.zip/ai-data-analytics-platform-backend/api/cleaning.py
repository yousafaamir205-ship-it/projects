import os

from flask import Blueprint, request

from analysis.data_cleaning import clean_dataset

cleaning_bp = Blueprint("cleaning", __name__)


@cleaning_bp.route("/clean", methods=["POST"])
def clean_route():

    data = request.get_json()

    filename = data.get("filename")

    if not filename:
        return {
            "status": "error",
            "message": "filename is required."
        }, 400

    dataset_path = os.path.join("uploads", filename)

    if not os.path.exists(dataset_path):
        return {
            "status": "error",
            "message": "Dataset not found."
        }, 404

    result = clean_dataset(dataset_path)

    return result
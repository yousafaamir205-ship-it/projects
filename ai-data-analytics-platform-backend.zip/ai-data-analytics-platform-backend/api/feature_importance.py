import os
import pandas as pd

from flask import Blueprint, request

from analysis.feature_importance import get_feature_importance

feature_bp = Blueprint("feature_importance", __name__)


@feature_bp.route("/feature-importance", methods=["POST"])
def feature_importance():

    data = request.get_json()

    filename = data.get("filename")

    target_column = data.get("target_column")

    if not filename or not target_column:

        return {
            "status": "error",
            "message": "filename and target_column are required."
        }, 400

    dataset_path = os.path.join("uploads", filename)

    if not os.path.exists(dataset_path):

        return {
            "status": "error",
            "message": "Dataset not found."
        }, 404

    df = pd.read_csv(dataset_path)

    importance = get_feature_importance(df, target_column)

    return {
        "status": "success",
        "feature_importance": importance
    }
import os
import pandas as pd

from flask import Blueprint, request

from analysis.hyperparameter_tuning import tune_decision_tree

tuning_bp = Blueprint("tuning", __name__)


@tuning_bp.route("/tune", methods=["POST"])
def tune_model():

    data = request.get_json()

    filename = data.get("filename")

    target_column = data.get("target_column")

    if not filename or not target_column:

        return {
            "status": "error",
            "message": "filename and target_column are required."
        }, 400

    dataset_path = os.path.join("uploads", filename)

    if not os.path.exists(dataset_path):

        return {
            "status": "error",
            "message": "Dataset not found."
        }, 404

    df = pd.read_csv(dataset_path)

    result = tune_decision_tree(df, target_column)

    return {
        "status": "success",
        "tuning_result": result
    }
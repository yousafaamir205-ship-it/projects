from analysis.model_training import compare_models
from database.history import save_training
import os
import pandas as pd

from flask import Blueprint, request

from analysis.model_training import train_decision_tree

train_bp = Blueprint("train", __name__)


@train_bp.route("/train", methods=["POST"])
def train_model():

    data = request.get_json()

    filename = data.get("filename")
    target_column = data.get("target_column")

    if not filename or not target_column:
        return {
            "status": "error",
            "message": "filename and target_column are required."
        }, 400

    dataset_path = os.path.join("uploads", filename)

    if not os.path.exists(dataset_path):
        return {
            "status": "error",
            "message": "Dataset not found."
        }, 404

    df = pd.read_csv(dataset_path)
    result = compare_models(df, target_column)
    save_training(
    filename,
    result["best_model"],
    result["best_accuracy"]
    )

    return {
        "status": "success",
        "training_result": result
    }
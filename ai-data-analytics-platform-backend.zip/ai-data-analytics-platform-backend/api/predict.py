import os

from flask import Blueprint, request

from analysis.prediction import predict

predict_bp = Blueprint("predict", __name__)


@predict_bp.route("/predict", methods=["POST"])
def predict_route():

    data = request.get_json()

    input_data = data.get("input_data")

    if input_data is None:
        return {
            "status": "error",
            "message": "input_data is required."
        }, 400

    model_path = os.path.join("models", "best_model.pkl")

    result = predict(model_path, input_data)

    return result
import os
import pandas as pd

from flask import Blueprint, request

from analysis.model_training import compare_models
from analysis.report_generator import generate_report

report_bp = Blueprint("report", __name__)


@report_bp.route("/report", methods=["POST"])
def report():

    data = request.get_json()

    filename = data.get("filename")
    target_column = data.get("target_column")

    if not filename or not target_column:

        return {
            "status": "error",
            "message": "filename and target_column are required."
        }, 400

    dataset_path = os.path.join("uploads", filename)

    if not os.path.exists(dataset_path):

        return {
            "status": "error",
            "message": "Dataset not found."
        }, 404

    df = pd.read_csv(dataset_path)

    model_result = compare_models(df, target_column)

    report_path = generate_report(
        filename,
        df,
        model_result
    )

    return {
        "status": "success",
        "report": report_path
    }
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
import os
import joblib
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
def train_decision_tree(df, target_column):

    X = df.drop(columns=[target_column])

    y = df[target_column]

    X = X.select_dtypes(include=["number"])

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.2,
        random_state=42
    )
    model = DecisionTreeClassifier()

    model.fit(X_train, y_train)

    predictions = model.predict(X_test)

    accuracy = accuracy_score(y_test, predictions)

    os.makedirs("models", exist_ok=True)

    model_path = os.path.join("models", "decision_tree.pkl")

    joblib.dump(model, model_path)

    return {
        "model": "Decision Tree",
        "accuracy": round(accuracy * 100, 2),
        "model_path": model_path
    }
def compare_models(df, target_column):
    print("compare_models() is running...")

    X = df.drop(columns=[target_column])
    y = df[target_column]
    X = X.select_dtypes(include=["number"])

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.2,
        random_state=42
    )

    models = {
    "Decision Tree": DecisionTreeClassifier(random_state=42),
    "Random Forest": RandomForestClassifier(random_state=42),
    "Logistic Regression": LogisticRegression(max_iter=1000),
    "KNN": KNeighborsClassifier(n_neighbors=3)
    }  

    results = {}

    best_model = None
    best_accuracy = 0

    for name, model in models.items():

        model.fit(X_train, y_train)

        predictions = model.predict(X_test)

        accuracy = accuracy_score(y_test, predictions)

        results[name] = round(accuracy * 100, 2)

        if best_model is None or accuracy >= best_accuracy:

            best_accuracy = accuracy
            best_model = model

    os.makedirs("models", exist_ok=True)

    best_model_path = os.path.join("models", "best_model.pkl")
    print("Saving best model to:", best_model_path)

    joblib.dump(best_model, best_model_path)

    return {
        "results": results,
        "best_model": max(results, key=results.get),
        "best_accuracy": round(best_accuracy * 100, 2),
        "saved_model": best_model_path
    }
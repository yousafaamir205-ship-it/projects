import os
import joblib
import pandas as pd


def predict(model_path, input_data):

    if not os.path.exists(model_path):
        return {
            "status": "error",
            "message": "Model not found."
        }

    model = joblib.load(model_path)

    df = pd.DataFrame([input_data])

    prediction = model.predict(df)

    return {
        "status": "success",
        "prediction": prediction[0]
    }
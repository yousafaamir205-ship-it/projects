import os
import matplotlib.pyplot as plt


def generate_visualizations(df):

    os.makedirs("visualizations", exist_ok=True)

    numeric_df = df.select_dtypes(include=["number"])

    generated_files = []
    numeric_df.hist(figsize=(10, 6))

    histogram_path = os.path.join(
        "visualizations",
        "histogram.png"
    )

    plt.savefig(histogram_path)

    plt.close()

    generated_files.append(histogram_path)
    plt.figure(figsize=(10, 6))

    numeric_df.boxplot()

    boxplot_path = os.path.join(
        "visualizations",
        "boxplot.png"
    )

    plt.savefig(boxplot_path)

    plt.close()

    generated_files.append(boxplot_path)
    plt.figure(figsize=(8, 6))

    correlation = numeric_df.corr()

    plt.imshow(correlation)

    plt.colorbar()

    plt.xticks(
        range(len(correlation.columns)),
        correlation.columns,
        rotation=45
    )

    plt.yticks(
        range(len(correlation.columns)),
        correlation.columns
    )

    heatmap_path = os.path.join(
        "visualizations",
        "correlation_heatmap.png"
    )

    plt.tight_layout()

    plt.savefig(heatmap_path)

    plt.close()

    generated_files.append(heatmap_path)

    return generated_files
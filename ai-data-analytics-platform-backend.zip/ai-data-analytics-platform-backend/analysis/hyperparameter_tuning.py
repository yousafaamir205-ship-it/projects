from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import accuracy_score


def tune_decision_tree(df, target_column):

    X = df.drop(columns=[target_column])

    y = df[target_column]
    if len(df) < 10:
        return {
        "message": "Dataset is too small for GridSearchCV. Please use a larger dataset (at least 10 samples)."
        }

    X = X.select_dtypes(include=["number"])

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.2,
        random_state=42
    )

    parameter_grid = {
        "max_depth": [2, 3, 5, None],
        "criterion": ["gini", "entropy"],
        "min_samples_split": [2, 4, 6]
    }

    grid = GridSearchCV(
        DecisionTreeClassifier(random_state=42),
        parameter_grid,
        cv=2
    )

    grid.fit(X_train, y_train)

    best_model = grid.best_estimator_

    predictions = best_model.predict(X_test)

    accuracy = accuracy_score(y_test, predictions)

    return {
        "best_parameters": grid.best_params_,
        "best_accuracy": round(accuracy * 100, 2)
    }
import os
import matplotlib.pyplot as plt
import seaborn as sns
def generate_visualizations(df, output_folder):

    image_paths = []

    numeric_columns = df.select_dtypes(include=["number"]).columns

    for column in numeric_columns:

        plt.figure(figsize=(6,4))

        sns.histplot(df[column], kde=True)

        plt.title(f"{column} Distribution")

        filename = f"{column}_histogram.png"

        save_path = os.path.join(output_folder, filename)

        plt.savefig(save_path)

        plt.close()

        image_paths.append(filename)

    return image_paths
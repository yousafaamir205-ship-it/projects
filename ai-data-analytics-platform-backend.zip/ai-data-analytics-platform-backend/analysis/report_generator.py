import os

from reportlab.platypus import SimpleDocTemplate
from reportlab.platypus import Paragraph
from reportlab.lib.styles import getSampleStyleSheet


def generate_report(filename, dataframe, model_result):

    os.makedirs("reports", exist_ok=True)

    report_path = os.path.join("reports", "analysis_report.pdf")

    document = SimpleDocTemplate(report_path)

    styles = getSampleStyleSheet()

    story = []

    story.append(
        Paragraph("<b>AI DATA ANALYTICS REPORT</b>", styles["Title"])
    )

    story.append(
        Paragraph(f"Filename: {filename}", styles["BodyText"])
    )

    story.append(
        Paragraph(f"Rows: {dataframe.shape[0]}", styles["BodyText"])
    )

    story.append(
        Paragraph(f"Columns: {dataframe.shape[1]}", styles["BodyText"])
    )

    story.append(
        Paragraph("<br/><b>Column Names</b>", styles["Heading2"])
    )

    for column in dataframe.columns:
        story.append(
            Paragraph(column, styles["BodyText"])
        )

    story.append(
        Paragraph("<br/><b>Machine Learning Result</b>", styles["Heading2"])
    )

    story.append(
        Paragraph(
            f"Best Model: {model_result['best_model']}",
            styles["BodyText"]
        )
    )

    story.append(
        Paragraph(
            f"Accuracy: {model_result['best_accuracy']}%",
            styles["BodyText"]
        )
    )

    document.build(story)

    return report_path
import os
import pandas as pd


def clean_dataset(file_path):

    if file_path.endswith(".csv"):
        df = pd.read_csv(file_path)
    else:
        df = pd.read_excel(file_path)

    original_rows = len(df)

    df = df.drop_duplicates()

    duplicates_removed = original_rows - len(df)

    numeric_columns = df.select_dtypes(include=["number"]).columns

    for column in numeric_columns:
        df[column] = df[column].fillna(df[column].mean())

    text_columns = df.select_dtypes(include=["object"]).columns

    for column in text_columns:
        df[column] = df[column].fillna("Unknown")

    os.makedirs("cleaned_data", exist_ok=True)

    cleaned_filename = "cleaned_" + os.path.basename(file_path)

    cleaned_path = os.path.join("cleaned_data", cleaned_filename)

    df.to_csv(cleaned_path, index=False)

    return {
    "status": "success",
    "cleaned_file": cleaned_filename,
    "rows_after_cleaning": int(len(df)),
    "duplicates_removed": int(duplicates_removed),
    "missing_values_remaining": int(df.isnull().sum().sum())
    }
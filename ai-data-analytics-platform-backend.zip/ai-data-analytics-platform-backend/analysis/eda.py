import pandas as pd
def analyze_dataset(df):
    """
    Perform basic exploratory data analysis.
    """
    analysis = {
        "rows": len(df),
        "columns": len(df.columns),
        "column_names": df.columns.tolist(),
        "data_types": df.dtypes.astype(str).to_dict(),
        "missing_values": df.isnull().sum().to_dict(),
        "duplicate_rows": int(df.duplicated().sum())
    }
    return analysis
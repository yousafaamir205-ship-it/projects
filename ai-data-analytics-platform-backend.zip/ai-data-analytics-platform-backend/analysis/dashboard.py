import os
import pandas as pd


def dataset_dashboard(filename):

    dataset_path = os.path.join("uploads", filename)

    if not os.path.exists(dataset_path):
        return {
            "status": "error",
            "message": "Dataset not found."
        }

    if filename.endswith(".csv"):
        df = pd.read_csv(dataset_path)
    else:
        df = pd.read_excel(dataset_path)

    dashboard = {
        "status": "success",
        "filename": filename,
        "rows": len(df),
        "columns": len(df.columns),
        "column_names": list(df.columns),
        "data_types": df.dtypes.astype(str).to_dict(),
        "missing_values": df.isnull().sum().to_dict(),
        "duplicate_rows": int(df.duplicated().sum()),
        "memory_usage_kb": round(
            df.memory_usage(deep=True).sum() / 1024,
            2
        ),
        "summary": df.describe(include="all").fillna("").to_dict()
    }

    return dashboard
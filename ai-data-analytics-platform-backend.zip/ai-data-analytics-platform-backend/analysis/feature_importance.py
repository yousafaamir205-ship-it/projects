import pandas as pd
from sklearn.tree import DecisionTreeClassifier
def get_feature_importance(df, target_column):
    X = df.drop(columns=[target_column])
    y = df[target_column]
    X = X.select_dtypes(include=["number"])

    model = DecisionTreeClassifier(random_state=42)

    model.fit(X, y)

    importance = model.feature_importances_

    result = {}

    for column, score in zip(X.columns, importance):
        result[column] = round(float(score), 4)

    return result
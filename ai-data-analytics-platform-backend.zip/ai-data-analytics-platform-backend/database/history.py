from database.connection import get_connection


def save_training(filename, model_name, accuracy):

    connection = get_connection()

    cursor = connection.cursor()

    cursor.execute("""

        INSERT INTO training_history

        (filename, model_name, accuracy)

        VALUES (?, ?, ?)

    """, (filename, model_name, accuracy))

    connection.commit()

    connection.close()